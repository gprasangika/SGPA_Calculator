function result()
{
    var tcredit = 0
    var total = 0
    var mul 
    var l
    for(var x=0;x<numSub;x++)
    {
        l = x.toString()
        tcredit += Number(document.getElementById("c"+l).value)
        mul = Number(document.getElementById("c"+l).value)* Number(document.getElementById("v"+l).value)
        total += mul
        
    }
    var res = total/tcredit
    alert("Your SGPA = "+ res.toFixed(2))


}
