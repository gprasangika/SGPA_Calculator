
function render()
{
    numSub = Number(document.getElementById("subno").value)
    var i
    document.write("<!DOCTYPE html><html><head><style>.g{margin: 5px;}</style><script src = \"helper.js\"></script><title>Enter Subject Data</title></head><body><form>")
    var cc 
    var a
    var b
    for(i = 0; i<numSub;i++)
    {
        cc = i.toString()
        a = "c"+cc
        b = "v"+cc
        document.write("Subject "+ (i+1) +" credit : <input type =\"number\" step = \"any\" class =\"g\" id ="+a+" />   Value : <input type =\"number\" step = \"any\" class = \"g\" id= "+b+" /></br>")

    }
    document.write("<input type=\"button\" value = \"Submit\" onclick = \"result()\"/></form></body></html>")
    
}